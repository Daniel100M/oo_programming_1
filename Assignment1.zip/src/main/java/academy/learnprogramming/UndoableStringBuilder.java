package academy.learnprogramming;

import java.util.ArrayList;
import java.util.List;

/**
 * Similar to the built-in StringBuilder class.
 * Difference is, this class allows the use of an 'undo' operation.
 * @author Daniel Makmal
 * @author Noam Saide
 */
public class UndoableStringBuilder {


    private StringBuilder stringBuilder; // All operations will involve manipulating this String.

    /*
     * This field is used to track the different operations performed by the user of the class.
     * This will allow the use of the 'undo' method.
     */
    private List<String> previousValues;

    /**
     * Creates a new object of type 'UndoableStringBuilder'.
     * Initializing fields.
     */
    public UndoableStringBuilder() {

        stringBuilder = new StringBuilder();
        previousValues = new ArrayList<>();
    }

    /**
     * To-String function. Used for printing contents of current object.
     * @return This String field.
     */
    @Override
    public String toString() {
        return stringBuilder.toString();
    }

    /**
     * Appends a String value (parameter) to the end of the current String field value.
     * @param str Appends 'str' String value to the end of this object's String field.
     * @return this object, with the updated String value.
     */
    public UndoableStringBuilder append(String str){

        stringBuilder.append(str);
        previousValues.add(stringBuilder.toString());

        return this;
    }

    /**
     * Deletes a sub-sequence of characters within this objects's String value.
     * @param start Index position. The characters from this point until 'end-1' will be deleted.
     * @param end Index position. The characters up until 'end-1' will be deleted.
     * @return this object, with the updated String value.
     */
    public UndoableStringBuilder delete(int start, int end){

        stringBuilder.delete(start, end);

        previousValues.add(stringBuilder.toString());

        return this;
    }

    /**
     * Inserts a sequence of characters into this field String value.
     * The position of insertion is determined by the user.
     * Sequence of characters shall be inserted at index 'offset + 1'.
     * Can be at the start, end, or middle of the character sequence.
     * @param offset Index position. Determines where to insert the String value.
     * @param str String value to be inserted into this sequence of characters.
     * @return this object, with the updated String value.
     */
    public UndoableStringBuilder insert(int offset, String str){

        stringBuilder.insert(offset, str);

        previousValues.add(stringBuilder.toString());

        return this;
    }

    /**
     * Replace a sub-sequence of characters of this object's field, with another sequence.
     * @param start Index position. The characters from this point until 'end-1' will be replaced.
     * @param end Index position. The characters up until 'end-1' will be replaced.
     * @param str String value (sequence of characters) to replace a sub-sequence of the object's String field.
     * @return this object, with the updated String value.
     */
    public UndoableStringBuilder replace(int start, int end, String str){

        stringBuilder.replace(start, end, str);
        previousValues.add(stringBuilder.toString());

        return this;
    }


    /**
     * Reverse this object's String field value.
     * @return this object, with the updated String value.
     */
    public UndoableStringBuilder reverse(){

        stringBuilder.reverse();
        previousValues.add(stringBuilder.toString());

        return this;
    }

    /**
     * Undo operation. Erase the last operation performed on the object.
     */
    public void undo(){

        if (previousValues.isEmpty()) return; // Nothing to undo.

        int last = previousValues.size()-1;
        String lastString = previousValues.get(last);

        previousValues.remove(lastString);

        if (previousValues.isEmpty()) stringBuilder = new StringBuilder();

        else {
            last--;
            stringBuilder = new StringBuilder(previousValues.get(last));
        }
    }
}
