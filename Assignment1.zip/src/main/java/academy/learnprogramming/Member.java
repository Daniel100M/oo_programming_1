package academy.learnprogramming;

public interface Member {

    void update(UndoableStringBuilder usb);
}
