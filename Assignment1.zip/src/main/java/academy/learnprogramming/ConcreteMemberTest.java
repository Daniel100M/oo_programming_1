package academy.learnprogramming;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ConcreteMemberTest {

    private GroupAdmin groupAdmin = new GroupAdmin();

    @Test
    void update() {

        /**
         * Registering 10 members (Observers)
         * to the collection.
         */
        for (int i = 0; i < 10; i++) {
            groupAdmin.register(new ConcreteMember());
        }

        groupAdmin.append("Chemistry.");

        /**
         * Checking that each member in the group
         * has indeed been updated after the change
         * to USB object.
         */
        for (Member member : groupAdmin.getMembers()){

            ConcreteMember concreteMember = (ConcreteMember) member;
            assertEquals("Chemistry.", concreteMember.getUsb().toString());
        }

        groupAdmin.insert(8, " class");

        /**
         * Checking.
         */
        for (Member member : groupAdmin.getMembers()){

            ConcreteMember concreteMember = (ConcreteMember) member;
            assertEquals("Chemistry class.", concreteMember.getUsb().toString());
        }

        groupAdmin.delete(0, 10);

        /**
         * Checking.
         */
        for (Member member : groupAdmin.getMembers()){

            ConcreteMember concreteMember = (ConcreteMember) member;
            assertEquals("class.", concreteMember.getUsb().toString());
        }
    }
}