package academy.learnprogramming;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ConcreteMemberTest {

    private GroupAdmin groupAdmin = new GroupAdmin();

    @Test
    void update() {

        groupAdmin.append("Science");

        /**
         * Registering 10 members (Observers)
         * to the collection.
         */
        for (int i = 0; i < 10; i++) {
            groupAdmin.register(new ConcreteMember(groupAdmin.getUsb()));
        }

        /*
         * Checking that each member in the group
         * has indeed been updated after the change
         * to USB object.
         */
        for (Member member : groupAdmin.getMembers()){

            ConcreteMember concreteMember = (ConcreteMember) member;
            assertEquals("Science", concreteMember.getUsb().toString());
        }

        groupAdmin.append(" Chemistry,");

        /*
        Checking.
         */
        for (Member member : groupAdmin.getMembers()){

            ConcreteMember concreteMember = (ConcreteMember) member;
            assertEquals("Science Chemistry,", concreteMember.getUsb().toString());
        }

        groupAdmin.insert(groupAdmin.getUsb().toString().length(), " class.");

        /*
         * Checking.
         */
        for (Member member : groupAdmin.getMembers()){

            ConcreteMember concreteMember = (ConcreteMember) member;
            assertEquals("Science Chemistry, class.", concreteMember.getUsb().toString());
        }

        groupAdmin.delete(0, 19);

        /*
         * Checking.
         */
        for (Member member : groupAdmin.getMembers()){

            ConcreteMember concreteMember = (ConcreteMember) member;
            assertEquals("class.", concreteMember.getUsb().toString());
        }
    }
}