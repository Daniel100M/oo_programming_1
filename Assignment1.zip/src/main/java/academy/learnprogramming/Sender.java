package academy.learnprogramming;

public interface Sender {

    /**
     * Register a new member (observer) to
     * this subject (GroupAdmin which implements this interface).
     * @param obj
     */
    void register(Member obj);

    void unregister(Member obj);

    /**
     * Inserts the string into this character sequence.
     * @param offset
     * @param obj
     */
    void insert(int offset, String obj);

    /**
     * Appends a String value (parameter as specified) to the end of this character sequence.
     * @param obj Appends 'obj' String value to the end of USB-object String field.
     */
    void append(String obj);

    /**
     * Removes the characters in a substring of this sequence.
     * @param start
     * @param end
     */
    void delete(int start, int end);

    /**
     * Erases the last change done to the document, reverting
     * it to an older state.
     */
    void undo();
}
