package academy.learnprogramming;

import java.util.ArrayList;
import java.util.List;

public class GroupAdmin implements Sender{

    /**
     * This List contains all the members which belong to
     * this object class.
     * Can only add objects which implement the 'Member' interface.
     */
    private List<Member> members;

    /**
     * This object contains (as a list field) all its previous states
     * including the current state (last element of list).
     */
    private UndoableStringBuilder usb;

    /**
     * Constructor for class.
     * Initializes the collection of members,
     * and UndoableStringBuilder object with an empty string.
     */
    public GroupAdmin() {

        members = new ArrayList<>();
        usb = new UndoableStringBuilder();
    }

    /**
     * A notify function which
     * updates all observers.
     * Will be called upon automatically whenever
     * state of field (UndoableStringBuilder) has been changed.
     */
    private void notifyMembers(){

        for (Member member : members){
            member.update(usb);
        }
    }

    public List<Member> getMembers() {
        return members;
    }

    public UndoableStringBuilder getUsb() {
        return usb;
    }

    @Override
    public void register(Member obj) {

        if (members.contains(obj)) return;

        members.add(obj);
    }

    @Override
    public void unregister(Member obj) {

        if (!members.contains(obj)) return;

        members.remove(obj);
    }

    @Override
    public void insert(int offset, String obj) {

        usb.insert(offset, obj);
        notifyMembers();
    }

    @Override
    public void append(String obj) {

        usb.append(obj);
        notifyMembers();
    }

    @Override
    public void delete(int start, int end) {

        usb.delete(start, end);
        notifyMembers();
    }

    @Override
    public void undo() {

        usb.undo();
        notifyMembers();
    }
}
