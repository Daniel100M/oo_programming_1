package academy.learnprogramming;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UndoableStringBuilderTest {

    private UndoableStringBuilder usb = new UndoableStringBuilder();

    @Test
    void append() {
        usb.append("to be or not to be");
        assertEquals("to be or not to be", usb.toString());
    }

    @Test
    void delete() {

        usb.append("can you132&*^ delete?");
        usb.delete(7, 13);

        assertEquals("can you delete?", usb.toString());

        try {
            usb.delete(-2,3);
        } catch (StringIndexOutOfBoundsException e){
            System.out.println("Invalid arguments sent.");
        }
    }

    @Test
    void insert() {

        usb.append("Hi, my name is .");
        usb.insert(14, "Daniel");

        assertEquals("Hi, my name is Daniel.", usb.toString());

        try {
            usb.insert(-2,"Test");
        } catch (StringIndexOutOfBoundsException e){
            System.out.println("Invalid arguments sent.");
        }
    }

    @Test
    void replace() {

        usb.append("to be or not to be");
        usb.replace(3,5,"eat");

        assertEquals("to eat or not to be", usb.toString());
    }

    @Test
    void reverse() {

        usb.append("kcehc esrever");
        usb.reverse();

        assertEquals("reverse check", usb.toString());
    }

    @Test
    void undo() {

        usb.append("Greetings");
        usb.append("!");
        usb.undo();

        assertEquals("Greetings", usb.toString());
    }
}