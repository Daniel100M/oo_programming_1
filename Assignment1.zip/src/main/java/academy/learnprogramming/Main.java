package academy.learnprogramming;

public class Main {

    public static void main(String[] args) {

        Sender sender;
        sender = new GroupAdmin();

        System.out.println("Before adding observers: " + JvmUtilities.objectTotalSize(sender));

        /*
        Registering 5 members to 'GroupAdmin'.
         */
        for (int i = 0; i < 5; i++) {

            sender.register(new ConcreteMember());
        }

        System.out.println("After adding observers: " + JvmUtilities.objectTotalSize(sender));

        sender.append("Incredible");

        System.out.println("After appending: " + JvmUtilities.objectTotalSize(sender));
    }
}
