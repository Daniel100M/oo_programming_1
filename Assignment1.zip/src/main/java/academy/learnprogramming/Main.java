package academy.learnprogramming;

public class Main {

    public static void main(String[] args) {

        Sender sender;
        sender = new GroupAdmin();

        System.out.println("Before adding observers:\n");
        System.out.println(JvmUtilities.objectTotalSize(sender) +
                "\n\nIn comprehensive detail:\n");
        System.out.println(JvmUtilities.objectFootprint(sender));


        /*
        Registering 5 members to 'GroupAdmin'.
         */
        for (int i = 0; i < 5; i++) {

            GroupAdmin groupAdmin = (GroupAdmin) sender;
            sender.register(new ConcreteMember(groupAdmin.getUsb()));
        }

        System.out.println("After adding observers: " + JvmUtilities.objectTotalSize(sender));

        sender.append("Incredible");

        System.out.println("After appending: " + JvmUtilities.objectTotalSize(sender));
    }
}
