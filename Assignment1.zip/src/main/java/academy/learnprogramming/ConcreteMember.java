package academy.learnprogramming;

public class ConcreteMember implements Member{

    /**
     * Member variable of this class.
     * Gets updated each time the 'update' method is called.
     * Shallow copy.
     */
    private UndoableStringBuilder usb;

    public ConcreteMember(UndoableStringBuilder usb) {
        this.usb = usb;
    }

    @Override
    public void update(UndoableStringBuilder usb) {
        this.usb = usb;
    }

    /**
     * Used to display current state of UndoableStringBuilder object.
     * Main purpose: Test that value has been updated.
     * @return Pointer to USB object.
     */
    public UndoableStringBuilder getUsb() {
        return usb;
    }
}
