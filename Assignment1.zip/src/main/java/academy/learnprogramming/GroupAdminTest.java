package academy.learnprogramming;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GroupAdminTest {

    private GroupAdmin groupAdmin = new GroupAdmin();

    @Test
    void register() {

        ConcreteMember concreteMember = new ConcreteMember();
        groupAdmin.register(concreteMember);

        /**
         * Checking to see whether member has been
         * added to observer collection.
         * Collection size must be incremented by 1.
         */
        assertEquals(1, groupAdmin.getMembers().size());

        /**
         * Trying to register the same member.
         * Shouldn't work. Size of collection must remain the same.
         */
        groupAdmin.register(concreteMember);

        assertEquals(1, groupAdmin.getMembers().size());

        ConcreteMember concreteMember1 = new ConcreteMember();
        groupAdmin.register(concreteMember1);

        /**
         * This time we've added a new object.
         * Again, validating that the collection has increased in size.
         */

        assertEquals(2, groupAdmin.getMembers().size());
    }

    @Test
    void unregister() {

        ConcreteMember concreteMember = new ConcreteMember();
        groupAdmin.register(concreteMember);

        /**
         * Unregistering the observer that has been added.
         * Collection should now be empty.
         * (size = 0)
         */
        groupAdmin.unregister(concreteMember);

        assertEquals(0, groupAdmin.getMembers().size());

        ConcreteMember concreteMember1 = new ConcreteMember();
        ConcreteMember concreteMember2 = new ConcreteMember();

        groupAdmin.register(concreteMember2);

        /**
         * Unregistering an object which does not exist.
         * Collection size must remain unchanged.
         */
        groupAdmin.unregister(concreteMember1);

        assertEquals(1, groupAdmin.getMembers().size());
    }

    @Test
    void insert() {

        /**
         * Initializing String with some value.
         */
        groupAdmin.append("Spicy ");

        groupAdmin.insert(5, "sauce.");

        assertEquals("Spicy sauce.", groupAdmin.getUsb().toString());

        groupAdmin.insert(4, " korean");

        assertEquals("Spicy korean sauce.", groupAdmin.getUsb().toString());

    }

    @Test
    void append() {

        groupAdmin.append("Popcorn!");

        assertEquals("Popcorn!", groupAdmin.getUsb().toString());

        groupAdmin.append(" How much?");

        assertEquals("Popcorn! How much?", groupAdmin.getUsb().toString());
    }

    @Test
    void delete() {

        groupAdmin.append("Some <delete> value...");

        groupAdmin.delete(5, 13);

        assertEquals("Some  value...", groupAdmin.getUsb().toString());
    }

    @Test
    void undo() {

        groupAdmin.append("Undo-me.");
        groupAdmin.undo();

        assertEquals("", groupAdmin.getUsb().toString());

        // ---------------------------

        groupAdmin.append("Green tea.");
        groupAdmin.insert(5, "English ");

        groupAdmin.undo();

        assertEquals("Green tea.", groupAdmin.getUsb().toString());

        groupAdmin.undo();

        assertEquals("", groupAdmin.getUsb().toString());

        // ---------------------------

        groupAdmin.append("First");
        groupAdmin.insert(4, " delete-message!");
        // First delete-message!

        groupAdmin.delete(6, 13);
        // First message!

        groupAdmin.append(" Fast speed.");
        groupAdmin.undo();

        assertEquals("First message!", groupAdmin.getUsb().toString());
    }
}